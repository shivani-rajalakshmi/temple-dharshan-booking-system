// Add this at the beginning of your booking.js file
document.addEventListener('DOMContentLoaded', function() {
    // Temple selection functionality
    document.querySelectorAll('.temple-card .select-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            // Remove previous selection
            document.querySelectorAll('.temple-card').forEach(card => {
                card.classList.remove('selected');
            });
            
            // Add selection to clicked temple
            const card = this.closest('.temple-card');
            card.classList.add('selected');
            
            // Get temple details
            const templeName = card.querySelector('h3').textContent;
            
            // Update selection summary
            document.getElementById('selectedTemple').textContent = templeName;
            document.getElementById('templeInput').value = templeName;
        });
    });
});

// Update the form submission code
document.getElementById('visitorForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    // Validate form data before submission
    const temple = document.getElementById('templeInput').value;
    const date = document.getElementById('dateInput').value;
    const time = document.getElementById('timeInput').value;
    const visitors = document.getElementById('visitors').value;
    const fullName = document.getElementById('fullName').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const amount = document.getElementById('amountInput').value;

    if (!temple || !date || !time || !visitors || !fullName || !email || !phone) {
        alert('Please fill in all required fields');
        return;
    }

    try {
        const formData = new FormData();
        formData.append('temple', temple);
        formData.append('date', date);
        formData.append('time', time);
        formData.append('visitors', visitors);
        formData.append('fullName', fullName);
        formData.append('email', email);
        formData.append('phone', phone);
        formData.append('amount', amount);

        const response = await fetch('process_booking.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (result.status === 'success') {
            alert('Booking successful!');
            window.location.href = 'payments.html';
        } else {
            alert('Booking failed: ' + result.message);
        }
    } catch (error) {
        console.error('Error details:', error);
        alert('An error occurred. Please try again.');
    }
});

// Add functions to update hidden inputs when selections are made
function updateTempleSelection(templeId, templeName) {
    document.getElementById('templeInput').value = templeId;
    document.getElementById('selectedTemple').textContent = templeName;
}

function updateDateSelection(date) {
    document.getElementById('dateInput').value = date;
    document.getElementById('selectedDate').textContent = date;
}

function updateTimeSelection(timeSlotId, time) {
    document.getElementById('timeInput').value = timeSlotId;
    document.getElementById('selectedTime').textContent = time;
}

// Calculate and update amount based on visitor count
document.getElementById('visitors').addEventListener('change', function() {
    const visitorCount = parseInt(this.value);
    const pricePerPerson = 100; // Set your price per person
    const totalAmount = visitorCount * pricePerPerson;
    
    document.getElementById('amountInput').value = totalAmount;
    document.getElementById('visitorCount').textContent = visitorCount;
    document.getElementById('totalAmount').textContent = '₹' + totalAmount;
});

// Calendar functionality
function generateCalendar() {
    const today = new Date();
    const currentMonth = document.getElementById('currentMonth');
    const calendarGrid = document.querySelector('.calendar-grid');
    
    // Clear existing calendar
    calendarGrid.innerHTML = '';
    
    // Set current month display
    currentMonth.textContent = today.toLocaleString('default', { month: 'long', year: 'numeric' });
    
    // Get first day of month and total days
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    
    // Add empty cells for days before first day of month
    for(let i = 0; i < firstDay.getDay(); i++) {
        const emptyDay = document.createElement('div');
        emptyDay.className = 'calendar-day disabled';
        calendarGrid.appendChild(emptyDay);
    }
    
    // Add days of month
    for(let day = 1; day <= lastDay.getDate(); day++) {
        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-day';
        dayElement.textContent = day;
        
        if(day === today.getDate()) {
            dayElement.classList.add('today');
        }
        
        dayElement.addEventListener('click', () => selectDate(day));
        calendarGrid.appendChild(dayElement);
    }
}

function selectDate(day) {
    // Remove previous selection
    document.querySelectorAll('.calendar-day').forEach(el => el.classList.remove('selected'));
    
    // Add selection to clicked day
    event.target.classList.add('selected');
    
    // Update selected date display
    const currentMonth = document.getElementById('currentMonth').textContent;
    document.getElementById('selectedDate').textContent = `${day} ${currentMonth}`;
    document.getElementById('dateInput').value = `${day} ${currentMonth}`;
}

// Time slot functionality
document.querySelectorAll('.time-slot').forEach(slot => {
    if (!slot.classList.contains('booked')) {
        slot.addEventListener('click', () => {
            // Remove previous selection
            document.querySelectorAll('.time-slot').forEach(s => s.classList.remove('selected'));
            
            // Add selection to clicked slot
            slot.classList.add('selected');
            
            // Update selected time display
            const time = slot.querySelector('.time').textContent;
            document.getElementById('selectedTime').textContent = time;
            document.getElementById('timeInput').value = time;
        });
    }
});

// Initialize calendar on page load
document.addEventListener('DOMContentLoaded', generateCalendar);

// Month navigation
document.getElementById('prevMonth').addEventListener('click', () => {
    // Add previous month logic
});

document.getElementById('nextMonth').addEventListener('click', () => {
    // Add next month logic
});