<?php
session_start();
if (!isset($_SESSION['isLoggedIn']) || $_SESSION['isLoggedIn'] !== true) {
    header('Location: login.html');
    exit();
}
?>
<!DOCTYPE html>
<!-- Rest of your existing portfolio HTML code -->