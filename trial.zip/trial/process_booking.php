<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Log incoming data
        error_log(print_r($_POST, true));

        // Validate data
        if (empty($_POST['temple']) || empty($_POST['date']) || 
            empty($_POST['visitors']) || empty($_POST['fullName'])) {
            throw new Exception('All fields are required');
        }

        $sql = "INSERT INTO bookings (temple_name, booking_date, booking_time, 
                visitor_count, full_name, email, phone, total_amount) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute([
            $_POST['temple'],
            $_POST['date'],
            $_POST['time'],
            $_POST['visitors'],
            $_POST['fullName'],
            $_POST['email'],
            $_POST['phone'],
            $_POST['amount']
        ]);

        if ($success) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Booking successful!',
                'redirect' => 'payments.html'
            ]);
        } else {
            throw new Exception('Failed to save booking');
        }
    } catch (Exception $e) {
        error_log($e->getMessage());
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method'
    ]);
}
?>